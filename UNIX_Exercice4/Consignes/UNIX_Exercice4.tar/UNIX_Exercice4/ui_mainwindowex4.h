/********************************************************************************
** Form generated from reading UI file 'mainwindowex4.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOWEX4_H
#define UI_MAINWINDOWEX4_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindowEx4
{
public:
    QWidget *centralwidget;
    QLabel *label_9;
    QLabel *label_8;
    QLabel *label_7;
    QLabel *label_3;
    QPushButton *pushButtonQuitter;
    QCheckBox *checkBoxTraitement1;
    QLabel *label_4;
    QLineEdit *lineEditResultat2;
    QPushButton *pushButtonDemarrerTraitements;
    QLineEdit *lineEditGroupe1;
    QLabel *label_5;
    QLabel *label_6;
    QLineEdit *lineEditGroupe3;
    QLineEdit *lineEditResultat3;
    QLineEdit *lineEditGroupe2;
    QLabel *label_2;
    QLabel *label;
    QCheckBox *checkBoxTraitement3;
    QPushButton *pushButtonVider;
    QCheckBox *checkBoxTraitement2;
    QLineEdit *lineEditResultat1;
    QPushButton *pushButtonAnnuler1;
    QPushButton *pushButtonAnnuler2;
    QPushButton *pushButtonAnnuler3;
    QPushButton *pushButtonAnnulerTous;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindowEx4)
    {
        if (MainWindowEx4->objectName().isEmpty())
            MainWindowEx4->setObjectName(QString::fromUtf8("MainWindowEx4"));
        MainWindowEx4->resize(699, 339);
        centralwidget = new QWidget(MainWindowEx4);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label_9 = new QLabel(centralwidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(20, 230, 64, 21));
        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(20, 200, 111, 17));
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(300, 230, 191, 21));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(300, 50, 191, 21));
        pushButtonQuitter = new QPushButton(centralwidget);
        pushButtonQuitter->setObjectName(QString::fromUtf8("pushButtonQuitter"));
        pushButtonQuitter->setGeometry(QRect(570, 290, 111, 25));
        checkBoxTraitement1 = new QCheckBox(centralwidget);
        checkBoxTraitement1->setObjectName(QString::fromUtf8("checkBoxTraitement1"));
        checkBoxTraitement1->setGeometry(QRect(130, 12, 121, 31));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(300, 140, 191, 21));
        lineEditResultat2 = new QLineEdit(centralwidget);
        lineEditResultat2->setObjectName(QString::fromUtf8("lineEditResultat2"));
        lineEditResultat2->setGeometry(QRect(490, 140, 91, 25));
        lineEditResultat2->setReadOnly(true);
        pushButtonDemarrerTraitements = new QPushButton(centralwidget);
        pushButtonDemarrerTraitements->setObjectName(QString::fromUtf8("pushButtonDemarrerTraitements"));
        pushButtonDemarrerTraitements->setGeometry(QRect(20, 290, 191, 25));
        pushButtonDemarrerTraitements->setStyleSheet(QString::fromUtf8("background-color:rgb(138, 226, 52)"));
        lineEditGroupe1 = new QLineEdit(centralwidget);
        lineEditGroupe1->setObjectName(QString::fromUtf8("lineEditGroupe1"));
        lineEditGroupe1->setGeometry(QRect(100, 50, 171, 25));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(20, 110, 111, 17));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(20, 140, 64, 21));
        lineEditGroupe3 = new QLineEdit(centralwidget);
        lineEditGroupe3->setObjectName(QString::fromUtf8("lineEditGroupe3"));
        lineEditGroupe3->setGeometry(QRect(100, 230, 171, 25));
        lineEditResultat3 = new QLineEdit(centralwidget);
        lineEditResultat3->setObjectName(QString::fromUtf8("lineEditResultat3"));
        lineEditResultat3->setGeometry(QRect(490, 230, 91, 25));
        lineEditResultat3->setReadOnly(true);
        lineEditGroupe2 = new QLineEdit(centralwidget);
        lineEditGroupe2->setObjectName(QString::fromUtf8("lineEditGroupe2"));
        lineEditGroupe2->setGeometry(QRect(100, 140, 171, 25));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 50, 64, 21));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 20, 111, 17));
        checkBoxTraitement3 = new QCheckBox(centralwidget);
        checkBoxTraitement3->setObjectName(QString::fromUtf8("checkBoxTraitement3"));
        checkBoxTraitement3->setGeometry(QRect(130, 190, 121, 31));
        pushButtonVider = new QPushButton(centralwidget);
        pushButtonVider->setObjectName(QString::fromUtf8("pushButtonVider"));
        pushButtonVider->setGeometry(QRect(240, 290, 83, 25));
        checkBoxTraitement2 = new QCheckBox(centralwidget);
        checkBoxTraitement2->setObjectName(QString::fromUtf8("checkBoxTraitement2"));
        checkBoxTraitement2->setGeometry(QRect(130, 100, 121, 31));
        lineEditResultat1 = new QLineEdit(centralwidget);
        lineEditResultat1->setObjectName(QString::fromUtf8("lineEditResultat1"));
        lineEditResultat1->setGeometry(QRect(490, 50, 91, 25));
        lineEditResultat1->setReadOnly(true);
        pushButtonAnnuler1 = new QPushButton(centralwidget);
        pushButtonAnnuler1->setObjectName(QString::fromUtf8("pushButtonAnnuler1"));
        pushButtonAnnuler1->setGeometry(QRect(600, 50, 83, 25));
        pushButtonAnnuler1->setStyleSheet(QString::fromUtf8("background-color:rgb(252, 175, 62)"));
        pushButtonAnnuler2 = new QPushButton(centralwidget);
        pushButtonAnnuler2->setObjectName(QString::fromUtf8("pushButtonAnnuler2"));
        pushButtonAnnuler2->setGeometry(QRect(600, 140, 83, 25));
        pushButtonAnnuler2->setStyleSheet(QString::fromUtf8("background-color:rgb(252, 175, 62)"));
        pushButtonAnnuler3 = new QPushButton(centralwidget);
        pushButtonAnnuler3->setObjectName(QString::fromUtf8("pushButtonAnnuler3"));
        pushButtonAnnuler3->setGeometry(QRect(600, 230, 83, 25));
        pushButtonAnnuler3->setStyleSheet(QString::fromUtf8("background-color:rgb(252, 175, 62)"));
        pushButtonAnnulerTous = new QPushButton(centralwidget);
        pushButtonAnnulerTous->setObjectName(QString::fromUtf8("pushButtonAnnulerTous"));
        pushButtonAnnulerTous->setGeometry(QRect(380, 290, 121, 25));
        pushButtonAnnulerTous->setStyleSheet(QString::fromUtf8("background-color:rgb(239, 41, 41)"));
        MainWindowEx4->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindowEx4);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 699, 22));
        MainWindowEx4->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindowEx4);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindowEx4->setStatusBar(statusbar);

        retranslateUi(MainWindowEx4);

        QMetaObject::connectSlotsByName(MainWindowEx4);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindowEx4)
    {
        MainWindowEx4->setWindowTitle(QApplication::translate("MainWindowEx4", "UNIX_Exercice4", nullptr));
        label_9->setText(QApplication::translate("MainWindowEx4", "Groupe :", nullptr));
        label_8->setText(QApplication::translate("MainWindowEx4", "<html><head/><body><p><span style=\" font-weight:600; color:#204a87;\">Traitement 3 :</span></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("MainWindowEx4", "Nombre d'\303\251tudiants trait\303\251s :", nullptr));
        label_3->setText(QApplication::translate("MainWindowEx4", "Nombre d'\303\251tudiants trait\303\251s :", nullptr));
        pushButtonQuitter->setText(QApplication::translate("MainWindowEx4", "Quitter", nullptr));
        checkBoxTraitement1->setText(QString());
        label_4->setText(QApplication::translate("MainWindowEx4", "Nombre d'\303\251tudiants trait\303\251s :", nullptr));
        pushButtonDemarrerTraitements->setText(QApplication::translate("MainWindowEx4", "D\303\251marrer les traitements", nullptr));
        label_5->setText(QApplication::translate("MainWindowEx4", "<html><head/><body><p><span style=\" font-weight:600; color:#204a87;\">Traitement 2 :</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("MainWindowEx4", "Groupe :", nullptr));
        label_2->setText(QApplication::translate("MainWindowEx4", "Groupe :", nullptr));
        label->setText(QApplication::translate("MainWindowEx4", "<html><head/><body><p><span style=\" font-weight:600; color:#204a87;\">Traitement 1 :</span></p></body></html>", nullptr));
        checkBoxTraitement3->setText(QString());
        pushButtonVider->setText(QApplication::translate("MainWindowEx4", "Vider", nullptr));
        checkBoxTraitement2->setText(QString());
        pushButtonAnnuler1->setText(QApplication::translate("MainWindowEx4", "Annuler", nullptr));
        pushButtonAnnuler2->setText(QApplication::translate("MainWindowEx4", "Annuler", nullptr));
        pushButtonAnnuler3->setText(QApplication::translate("MainWindowEx4", "Annuler", nullptr));
        pushButtonAnnulerTous->setText(QApplication::translate("MainWindowEx4", "Annuler tout", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindowEx4: public Ui_MainWindowEx4 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOWEX4_H
