#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>

typedef struct
{
  char nom[40];
  char email[40];
  int  anneeNaissance;
  char photo[40];
} ELEMENT;

ELEMENT Elm[] = 
{
  {"Achile Talon","achile.talon@gmail.com",1963,"Achile.jpg"},
  {"Gaston Lagaffe","gaston.lagaffe@gmail.com" , 1957,"Gaston.jpg"},
  {"Lucien","lucien@hepl.be",1979,"Lucien.jpg"},
  {"Robert Bidochon","robert.bidochon@hepl.com", 1977,"Bidochon.jpeg"}
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
MainWindow::MainWindow(QWidget *parent):QMainWindow(parent),ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setNom(Elm[0].nom);
    setEmail(Elm[0].email);
    setAnneeNaissance(Elm[0].anneeNaissance);
    setPhoto(Elm[0].photo);
}

MainWindow::~MainWindow()
{
    delete ui;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
///// Fonctions utiles : ne pas modifier /////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MainWindow::setNom(const char* Text)
{
  fprintf(stderr,"---%s---\n",Text);
  if (strlen(Text) == 0 )
  {
    ui->lineEditNom->clear();
    return;
  }
  ui->lineEditNom->setText(Text);
}

void MainWindow::setEmail(const char* Text)
{
  fprintf(stderr,"---%s---\n",Text);
  if (strlen(Text) == 0 )
  {
    ui->lineEditEmail->clear();
    return;
  }
  ui->lineEditEmail->setText(Text);
}

void MainWindow::setAnneeNaissance(int annee)
{
  char Text[20];
  sprintf(Text,"%d",annee);
  fprintf(stderr,"---%s---\n",Text);
  if (strlen(Text) == 0 )
  {
    ui->lineEditAnneeNaissance->clear();
    return;
  }
  ui->lineEditAnneeNaissance->setText(Text);
}

void MainWindow::setPhoto(const char* Text)
{
  fprintf(stderr,"---%s---\n",Text);
  if (strlen(Text) == 0 )
  {
    ui->lineEditPhoto->clear();
    return;
  }
  ui->lineEditPhoto->setText(Text);

  // Affichage de la photo a droite
  char  nomFichier[256];
  sprintf(nomFichier,"./photos/%s",Text);
  QPixmap Pix(nomFichier);
  ui->labelImage ->setPixmap(Pix);
  ui->labelImage->setScaledContents(true);
}

const char* MainWindow::getPhoto()
{
  if (ui->lineEditPhoto->text().size())
  { 
    strcpy(photo,ui->lineEditPhoto->text().toStdString().c_str());
    return photo;
  }
  return NULL;
}

const char* MainWindow::getEmail()
{
  if (ui->lineEditEmail->text().size())
  { 
    strcpy(email,ui->lineEditEmail->text().toStdString().c_str());
    return email;
  }
  return NULL;
}

const char* MainWindow::getNom()
{
  if (ui->lineEditNom->text().size())
  { 
    strcpy(nom,ui->lineEditNom->text().toStdString().c_str());
    return nom;
  }
  return NULL;
}

int MainWindow::getAnneeNaissance()
{
  if (ui->lineEditAnneeNaissance->text().size())
  {
    char tmp[40]; 
    strcpy(tmp,ui->lineEditAnneeNaissance->text().toStdString().c_str());
    return atoi(tmp);
  }
  return -1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
///// Fonctions clics sur les boutons ////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MainWindow::on_pushButtonPrecedent_clicked()
{
  fprintf(stderr,"Clic sur le bouton <<<\n");
  // TO DO
}

void MainWindow::on_pushButtonSuivant_clicked()
{
  fprintf(stderr,"Clic sur le bouton >>>\n");
  // TO DO
}

void MainWindow::on_pushButtonModifier_clicked()
{
  fprintf(stderr,"Clic sur le bouton Modifier\n");
  QMessageBox::StandardButton reponse;
  reponse = QMessageBox::question(this, "Modifier...", "Etes-vous certain de vouloir modifier cet enregistrement ?",QMessageBox::Yes|QMessageBox::No);
  if (reponse == QMessageBox::Yes)
  {
    fprintf(stderr,"Confirmation de modification\n");
    // TO DO
  }
}

void MainWindow::on_pushButtonQuitter_clicked()
{
  fprintf(stderr,"Clic sur le bouton Quitter\n");
  // TO DO
}
